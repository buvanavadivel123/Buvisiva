import pandas as pd
import numpy as np
import random as rnd

import seaborn as sns
import matplotlib.pyplot as plt

# %matplotlib inline

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC, LinearSVC
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

df = pd.read_csv("train.csv")
print(df)

print(df.columns.values)
print(df.head())
print(df.tail())
print(df.info())
print(df.describe())
print(df.columns)
print(df.index)
print(df.describe(include='all'))

Survived = df[['Pclass','Survived']].groupby(['Pclass'],as_index = False).median().sort_values(by="Survived",ascending=False)
print(Survived)

Gender_wise_survived = df[['Sex','Survived']].groupby(['Sex'],as_index= False).median().sort_values(by="Survived",ascending=False)
print(Gender_wise_survived)

Parch_wise_survived = df[['Parch','Survived']].groupby(['Parch'],as_index=False).median().sort_values(by='Survived',ascending=False)
print(Parch_wise_survived)

g=sns.FacetGrid(df,col='Survived')
g.map(plt.hist,'Age',bins=20)

print("Before",df.shape)
df = df.drop(['Ticket','Cabin'],axis = 1)
print("After",df.shape)

df = df.drop(['Name','PassengerId'],axis = 1)
print(df.shape)

df['Sex'] = df['Sex'].map({'female':1,'male':0})
print(df.head())

guess_ages = np.zeros((2,3))
print(guess_ages)

guess_ages = {}

for i in range(0,2):
    for j in range(0,3):
        guess_df = df[(df['Sex']==i)&(df['Pclass']==j+1)]['Age'].dropna()
        age_guess = guess_df.median()
        guess_ages[i,j+1] = age_guess

#Apply the imputation to the age column
for index,row in df.iterrows():
    sex = row['Sex']
    pclass = row['Pclass']
    age = row['Age']

    if pd.isnull(age):
        df.at[index,'Age'] = guess_ages.get((sex,pclass))

print(df.head())

df['AgeBand'] = pd.cut(df['Age'],5)
Fill_Values = df[['AgeBand','Survived']].groupby(['AgeBand'],as_index=False).median().sort_values(by = 'AgeBand',ascending=True)
print(Fill_Values)

for index,row in df.iterrows():
    if row['Age'] <= 16:
        df.at[index,'Age'] = 0
    elif 16 < row['Age'] <= 32:
        df.at[index,'Age'] = 1
    elif 32 < row['Age'] <= 48:
        df.at[index,'Age'] = 2
    elif 48 < row['Age'] <= 64:
        df.at[index,'Age'] = 3
    else:
        df.at[index,'Age'] = 4

print(df.head())

freq_port = df.Embarked.dropna().mode()[0]
print(freq_port)

freq_port = df['Embarked'].mode()[0]

df['Embarked'] = df['Embarked'].fillna(freq_port)

Embarked_survived = df[['Embarked', 'Survived']].groupby(['Embarked'], as_index=False).median().sort_values(by='Survived', ascending=False)
print(Embarked_survived)

df['Embarked'] = df['Embarked'].map({'S': 0, 'C': 1, 'Q': 2}).astype(int)
print(df.head())

df['Fare']=df['Fare'].fillna(df['Fare'].dropna().median(),inplace = False)
print(df.head())

df['FareBand'] = pd.qcut(df['Fare'],q=4)
FareBand_survived = df[['FareBand','Survived']].groupby(['FareBand'],as_index = False).median().sort_values(by='FareBand',ascending=True)
print(FareBand_survived)

for index,row in df.iterrows():
    if row['Fare'] <= 7.91:
        df.at[index,'Fare'] = 0
    elif 7.91 < row['Fare'] <= 14.454:
        df.at[index, 'Fare'] = 1
    elif 14.45 < row['Fare'] <= 31:
        df.at[index,'Fare'] = 2
    else:
        df.at[index,'Fare'] = 3

df['Fare'] = df['Fare'].astype(int)
df = df.drop('FareBand',axis=1)

print(df.head(10))

#Assuming df is your DataFrame and Survived is target

#Step 1:Convert categorical columns to numeric
# Option 1: Use pd.get_dummies() to one-hot encode categorical columns
x = pd.get_dummies(df.drop('Survived',axis = 1),drop_first= True)

# Option 2: Use LabelEncoder for categorical columns if they're ordinal
# label_encoder = LabelEncoder()
# x['some_categorical_column'] = label_encoder.fit_transform(x['some_categorical_column'])

# Step 2: Handle missing values
# Fill missing values with the column mode or drop missing values
x = x.fillna(x.mode()) # or df.dropna() if you prefer to drop missing rows


# Define target variable
y = df['Survived']


# Step 3: Split data into training and testing sets
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=42)

# Step 4: Train the Naive Bayes model
naive_bayes = GaussianNB()
naive_bayes.fit(x_train, y_train)

# Step 5: Predict the target for the test set
y_pred = naive_bayes.predict(x_test)

accuracy = accuracy_score(y_test,y_pred)
conf_matrix = confusion_matrix(y_test,y_pred)
classification_rep = classification_report(y_test,y_pred)

print(f"Accuracy:{accuracy:.2f}")
print("Confusion Matrix:")
print(conf_matrix)
print("Classification Report:")
print(classification_rep)

conf_matrix = confusion_matrix(y_test,y_pred)
sns.heatmap(conf_matrix,annot = True, fmt = 'd',cmap = 'Blues')
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()

from sklearn.metrics import roc_curve,auc

fpr,tpr,_ = roc_curve(y_test,y_pred)
roc_auc = auc(fpr,tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = {:.2f})'.format(roc_auc))
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='dotted')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()

from sklearn.model_selection import learning_curve

train_sizes, train_scores, test_scores = learning_curve(naive_bayes, x, y, cv=5, scoring='accuracy', train_sizes=np.linspace(0.1, 1.0, 10))

plt.figure()
plt.plot(train_sizes, np.mean(train_scores, axis=1), label='Training Score')
plt.plot(train_sizes, np.mean(test_scores, axis=1), label='Cross-Validation Score')
plt.xlabel('Training Set Size')
plt.ylabel('Accuracy Score')
plt.title('Learning Curve')
plt.legend(loc='best')
plt.show()

















